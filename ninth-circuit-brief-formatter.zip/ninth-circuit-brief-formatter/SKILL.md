---
name: ninth-circuit-brief-formatter
description: "Interactive brief formatting tool. Goes section-by-section with user classification, then Claude reviews and suggests edits shown as Word tracked changes for accept/reject"
license: MIT. See LICENSE.txt for details
---

# Ninth Circuit Brief Formatter

## Overview

This skill formats legal briefs through an interactive two-phase process:

**PHASE 1: Classification** - User decides what each section is (Heading 1, Heading 2, Body, Numbered Paragraph, etc.)

**PHASE 2: Review & Suggest** - Claude reads each section and suggests improvements as Word tracked changes (red lines)

**OUTPUT**: Two Word files to compare - one formatted, one with suggested edits

## Quick Start

```bash
python scripts/formatter.py YOUR_BRIEF.docx
```

## What It Does

### Phase 1: Interactive Classification

For each section in your brief:
1. Shows you the text
2. Asks: "What is this?" 
   - [H1] Heading 1 (STATEMENT OF THE CASE)
   - [H2] Heading 2 (I. THE ARREST)
   - [B] Body text
   - [N] Numbered paragraph (1. On March 4...)
   - [S] Skip/blank
3. Stores your choice
4. Moves to next section

### Phase 2: Content Review

For each section Claude has NOT seen yet:
1. Claude reads it
2. Suggests improvements (if any)
3. You decide: [A]ccept / [R]eject / [S]kip
4. Accepted edits become tracked changes

### Output Files

1. **BRIEF_FORMATTED.docx** - Your classifications applied
   - Century Schoolbook 14pt
   - Proper spacing
   - Correct heading styles

2. **BRIEF_WITH_EDITS.docx** - Suggested improvements as tracked changes
   - Red strikethrough for deletions
   - Blue underline for insertions
   - Accept/reject in Word

## Formatting Rules

### Heading 1 (App_Heading_1)
- All caps
- Centered
- Bold
- 14pt Century Schoolbook
- Single-spaced
- No numbers

Example: `STATEMENT OF THE CASE`

### Heading 2 (App_Heading_2)  
- All caps
- Left-aligned
- Bold
- 14pt Century Schoolbook
- Single-spaced
- Roman numerals (I., II., III.)

Example: `I. THE ASSIGNMENT OF BENEFITS`

### Body Text
- Normal capitalization
- Left-aligned
- 14pt Century Schoolbook
- Double-spaced (2.0)

### Numbered Paragraphs
- Starts with number (1., 2., 3.)
- Left-aligned
- 14pt Century Schoolbook
- Double-spaced (2.0)

## Interactive Prompts

### Classification Prompts
```
[Section 1/250]
"In mid-2020, homeowner Joanna Lee Bozian executed..."

What is this?
[H1] Main Heading  [H2] Subheading  [B] Body  [N] Numbered  [S] Skip
Choice: 
```

### Review Prompts
```
Reading Section 12...

Suggestion: Change "the homeowner died" to "Ms. Bozian passed away on [date]"

[A]ccept  [R]eject  [S]kip all suggestions for this section
Choice:
```

## Variables Stored Per Section

```python
{
    'index': 45,
    'text': 'Original paragraph text...',
    'classification': 'Heading2',  # or 'Body', 'Numbered', etc.
    'suggestions': [
        {
            'original': 'the homeowner died',
            'suggested': 'Ms. Bozian passed away',
            'accepted': True
        }
    ]
}
```

## Word XML Styles

The tool creates these custom styles:

### App_Heading_1
```xml
<w:style w:type="paragraph" w:styleId="AppHeading1">
  <w:name w:val="App Heading 1"/>
  <w:pPr>
    <w:spacing w:line="240" w:lineRule="auto"/>
    <w:jc w:val="center"/>
  </w:pPr>
  <w:rPr>
    <w:rFonts w:ascii="Century Schoolbook" w:hAnsi="Century Schoolbook"/>
    <w:b/><w:caps/>
    <w:sz w:val="28"/>
  </w:rPr>
</w:style>
```

### App_Heading_2
```xml
<w:style w:type="paragraph" w:styleId="AppHeading2">
  <w:name w:val="App Heading 2"/>
  <w:pPr>
    <w:spacing w:line="240" w:lineRule="auto"/>
    <w:jc w:val="left"/>
  </w:pPr>
  <w:rPr>
    <w:rFonts w:ascii="Century Schoolbook" w:hAnsi="Century Schoolbook"/>
    <w:b/><w:caps/>
    <w:sz w:val="28"/>
  </w:rPr>
</w:style>
```

### App_Body
```xml
<w:style w:type="paragraph" w:styleId="AppBody">
  <w:name w:val="App Body"/>
  <w:pPr>
    <w:spacing w:line="480" w:lineRule="auto"/>
  </w:pPr>
  <w:rPr>
    <w:rFonts w:ascii="Century Schoolbook" w:hAnsi="Century Schoolbook"/>
    <w:sz w:val="28"/>
  </w:rPr>
</w:style>
```

## Tracked Changes Format

Deletions and insertions use Word's standard tracked change XML:

```xml
<!-- Deletion -->
<w:del w:author="Claude" w:date="2024-12-07T06:30:00Z">
  <w:r><w:delText>old text</w:delText></w:r>
</w:del>

<!-- Insertion -->
<w:ins w:author="Claude" w:date="2024-12-07T06:30:00Z">
  <w:r><w:t>new text</w:t></w:r>
</w:ins>
```

## Tips

1. **Be precise with classification** - Once you pick Heading2, all similar sections should probably be Heading2

2. **Review phase is optional** - You can skip all suggestions if you just want formatting

3. **Compare in Word** - Open both files side-by-side to see all changes at once

4. **Accept/Reject in Word** - Use Review tab → Accept/Reject buttons for final control
